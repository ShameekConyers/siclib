from . import impl

def diff(array, index):
	return impl._diff(array, index)
